from azureml.core import Environment
from azureml.contrib.automl.dnn.vision.object_detection.data.datasets import ObjectDetectionDatasetBaseWrapper


class RunMock:

    def __init__(self, exp):
        self.experiment = exp
        self.metrics = {}
        self.properties = {}
        self.id = 'mock_run_id'

    def add_properties(self, properties):
        self.properties.update(properties)

    def log(self, metric_name, metric_val):
        self.metrics[metric_name] = metric_val

    def get_environment(self):
        return Environment('test_env')


class ExperimentMock:

    def __init__(self, ws):
        self.workspace = ws


class WorkspaceMock:

    def __init__(self, datastore):
        self._datastore = datastore

    def get_default_datastore(self):
        return self._datastore


class DatastoreMock:

    def __init__(self, name):
        self.name = name
        self.files = []
        self.dataset_file_content = []

    def path(self, file_path):
        return file_path

    def upload_files(self, files, relative_root=None, target_path=None, overwrite=False):
        self.files.append((files, relative_root, target_path, overwrite))
        if relative_root is None and len(files) == 1:
            with open(files[0], "r") as f:
                self.dataset_file_content = f.readlines()


class DatasetMock:

    def __init__(self, id):
        self.id = id


class LabeledDatasetFactoryMock:

    def __init__(self, dataset_id):
        self.task = ""
        self.path = ""
        self.dataset_id = dataset_id

    def from_json_lines(self, task, path):
        self.task = task
        self.path = path
        return DatasetMock(self.dataset_id)


class DatasetWrapperMock(ObjectDetectionDatasetBaseWrapper):

    def __init__(self, items, num_classes):
        self._items = items
        self._num_classes = num_classes
        self._classes = ["label_{}".format(i) for i in range(self._num_classes)]
        self._label_to_index_map = {i: self._classes[i] for i in range(self._num_classes)}

    def __getitem__(self, index):
        return self._items[index]

    def __len__(self):
        return len(self._items)

    @property
    def num_classes(self):
        return self._num_classes

    def label_to_index_map(self, label):
        return self._label_to_index_map[label]

    def index_to_label(self, index):
        return self._classes[index]

    @property
    def classes(self):
        return self._classes
