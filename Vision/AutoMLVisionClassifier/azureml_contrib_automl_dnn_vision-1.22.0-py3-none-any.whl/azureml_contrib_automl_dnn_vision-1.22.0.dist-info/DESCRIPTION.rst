AutoML DNN Vision Package. This package is only meant to be used by AutoML system-generated scripts. To install in Windows, the "torch" and "torchvision" packages must be installed separately before this package. Please see https://pytorch.org/ for instructions.



